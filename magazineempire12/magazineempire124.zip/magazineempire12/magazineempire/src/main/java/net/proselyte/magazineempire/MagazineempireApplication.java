package net.proselyte.magazineempire;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagazineempireApplication {
	public static void main(String[] args) {
		SpringApplication.run(MagazineempireApplication.class, args);
	}
}
