package net.proselyte.magazineempire.service;

public class CompilationService {
}
