package net.proselyte.magazineempire.model;

public class Compilation {
}
