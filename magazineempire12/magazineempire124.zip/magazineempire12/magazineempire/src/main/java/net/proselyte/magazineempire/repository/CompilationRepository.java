package net.proselyte.magazineempire.repository;
public interface CompilationRepository {
}
