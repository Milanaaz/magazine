package net.proselyte.magazineempire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagazineempireApplicationTests {

	@Test
	void contextLoads() {
	}

}
